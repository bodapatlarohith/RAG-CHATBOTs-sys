import re
import json
import subprocess
from datetime import datetime
from youtube_transcript_api import YouTubeTranscriptApi


def fetch_video_data(url: str) -> dict:
    """Auto-detect platform and fetch video data."""
    if "youtube.com" in url or "youtu.be" in url:
        return fetch_youtube_data(url)
    elif "instagram.com" in url:
        return fetch_instagram_data(url)
    else:
        raise ValueError(f"Unsupported platform URL: {url}")


def _extract_youtube_id(url: str) -> str:
    patterns = [
        r"(?:v=|youtu\.be/)([A-Za-z0-9_-]{11})",
        r"(?:embed/)([A-Za-z0-9_-]{11})",
    ]
    for p in patterns:
        m = re.search(p, url)
        if m:
            return m.group(1)
    raise ValueError(f"Could not extract YouTube ID from: {url}")


def fetch_youtube_data(url: str) -> dict:
    video_id = _extract_youtube_id(url)

    # Fetch metadata via yt-dlp
    try:
        result = subprocess.run(
            ["yt-dlp", "--dump-json", "--no-download", url],
            capture_output=True, text=True, timeout=60
        )
        meta = json.loads(result.stdout)
        title = meta.get("title", "Unknown Title")
        creator = meta.get("uploader", meta.get("channel", "Unknown"))
        views = int(meta.get("view_count") or 0)
        likes = int(meta.get("like_count") or 0)
        comments = int(meta.get("comment_count") or 0)
        duration = int(meta.get("duration") or 0)
        upload_date_raw = meta.get("upload_date", "")
        upload_date = (
            datetime.strptime(upload_date_raw, "%Y%m%d").strftime("%Y-%m-%d")
            if upload_date_raw else "N/A"
        )
        description = meta.get("description", "")[:500]
        hashtags = [t.get("term", "") for t in meta.get("tags", []) if isinstance(t, dict)]
        if not hashtags:
            hashtags = meta.get("tags", [])[:15]
        subscriber_count = int(meta.get("channel_follower_count") or 0)
    except Exception as e:
        print(f"yt-dlp metadata fetch failed: {e}")
        title = "YouTube Video"
        creator = "Unknown"
        views = likes = comments = duration = subscriber_count = 0
        upload_date = "N/A"
        description = ""
        hashtags = []

    # Fetch transcript
    transcript_text = ""
    try:
        transcript_list = YouTubeTranscriptApi.get_transcript(video_id)
        transcript_text = " ".join(item["text"] for item in transcript_list)
    except Exception as e:
        print(f"Transcript fetch failed for {video_id}: {e}")
        transcript_text = description  # Fall back to description

    # Engagement rate: (likes + comments) / views * 100
    engagement_rate = round((likes + comments) / max(views, 1) * 100, 2)

    return {
        "platform": "youtube",
        "video_id": video_id,
        "url": url,
        "title": title,
        "creator": creator,
        "follower_count": subscriber_count,
        "views": views,
        "likes": likes,
        "comments": comments,
        "duration_seconds": duration,
        "upload_date": upload_date,
        "description": description,
        "hashtags": hashtags,
        "engagement_rate": engagement_rate,
        "transcript": transcript_text,
    }


def fetch_instagram_data(url: str) -> dict:
    """
    Fetch Instagram reel data.
    Production path: yt-dlp audio -> Whisper for transcript.
    Demo: uses yt-dlp metadata + caption as transcript proxy.
    """
    try:
        result = subprocess.run(
            ["yt-dlp", "--dump-json", "--no-download", url],
            capture_output=True, text=True, timeout=60
        )
        meta = json.loads(result.stdout)
        title = meta.get("title", meta.get("description", "Instagram Reel"))[:100]
        creator = meta.get("uploader", meta.get("channel", "Unknown"))
        views = int(meta.get("view_count") or 0)
        likes = int(meta.get("like_count") or 0)
        comments = int(meta.get("comment_count") or 0)
        duration = int(meta.get("duration") or 0)
        description = meta.get("description", "")[:500]
        hashtags = re.findall(r"#\w+", description)
    except Exception as e:
        print(f"Instagram fetch failed: {e}")
        title = "Instagram Reel"
        creator = "Unknown"
        views = likes = comments = duration = 0
        description = ""
        hashtags = []

    engagement_rate = round((likes + comments) / max(views, 1) * 100, 2)

    return {
        "platform": "instagram",
        "video_id": url.split("/")[-2] if "/" in url else url,
        "url": url,
        "title": title,
        "creator": creator,
        "follower_count": 0,
        "views": views,
        "likes": likes,
        "comments": comments,
        "duration_seconds": duration,
        "upload_date": "N/A",
        "description": description,
        "hashtags": hashtags,
        "engagement_rate": engagement_rate,
        "transcript": description,  # Caption as proxy; replace with Whisper in prod
    }
