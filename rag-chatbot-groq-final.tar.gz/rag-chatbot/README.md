# Video RAG Chatbot

Compare two social media videos using AI. Ask questions about engagement, hooks, improvements, and more.

## Stack

- **Frontend**: React (Vite) — side-by-side video cards + streaming chat
- **Backend**: FastAPI (Python)
- **Embeddings**: OpenAI `text-embedding-3-small`
- **Vector DB**: Qdrant (in-memory, no server needed)
- **LLM**: GPT-4o with streaming
- **Transcripts**: youtube-transcript-api + yt-dlp

## Setup

### 1. Add your API key

```bash
cd backend
copy .env.example .env
# Open .env and set OPENAI_API_KEY=sk-...
```

### 2. Backend

```bash
cd backend
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # Mac/Linux
pip install -r requirements.txt
python main.py
```

Backend runs at: http://localhost:8000

### 3. Frontend

Open a new terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at: http://localhost:5173

## Usage

1. Open http://localhost:5173
2. Paste two YouTube (or Instagram) URLs
3. Click **Analyse Videos**
4. Wait ~20-30 seconds for transcript ingestion
5. Ask questions in the chat

## Demo URLs (TED Talks)

- Video A: `https://www.youtube.com/watch?v=arj7oStGLkU`
- Video B: `https://www.youtube.com/watch?v=mNBmG24djoY`

## RAG Architecture

```
User Question
    → similarity_search() → Qdrant finds top 8 chunks
    → chunks injected into GPT-4o system prompt
    → GPT-4o generates answer with source citations
    → streams back to UI via SSE
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/ingest` | Fetch + embed two videos |
| POST | `/chat` | Streaming chat (SSE) |
| GET | `/videos` | Get video metadata |
| POST | `/chat/reset` | Reset chat history |
