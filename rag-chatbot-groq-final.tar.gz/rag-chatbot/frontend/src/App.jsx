import { useState, useRef, useEffect } from "react";

const API = "http://localhost:8000";

const SUGGESTIONS = [
  "Compare the hooks of both videos",
  "Which video has better engagement rate?",
  "What improvements can Video B learn from A?",
  "Summarize the main topic of each video",
  "What hashtags performed best?",
];

function StatBadge({ label, value, color }) {
  return (
    <div style={{
      background: "#ffffff08",
      border: `1px solid ${color}33`,
      borderRadius: 8,
      padding: "6px 10px",
      textAlign: "center",
      flex: 1,
    }}>
      <div style={{ fontSize: 11, color: "#8888a8", marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 600, color }}>{value}</div>
    </div>
  );
}

function VideoCard({ label, data, color }) {
  const fmt = (n) => n >= 1_000_000
    ? (n / 1_000_000).toFixed(1) + "M"
    : n >= 1_000
    ? (n / 1_000).toFixed(1) + "K"
    : String(n);

  return (
    <div style={{
      background: "#111118",
      border: `1px solid ${color}44`,
      borderRadius: 16,
      padding: 20,
      flex: 1,
      position: "relative",
      overflow: "hidden",
    }}>
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0, height: 3,
        background: `linear-gradient(90deg, ${color}, transparent)`,
      }} />
      <div style={{
        display: "inline-block",
        background: color + "22",
        border: `1px solid ${color}55`,
        borderRadius: 20,
        padding: "3px 12px",
        fontSize: 11,
        fontWeight: 700,
        color,
        marginBottom: 10,
        textTransform: "uppercase",
        letterSpacing: 1,
      }}>
        Video {label} · {data.platform}
      </div>
      <div style={{
        fontFamily: "Syne, sans-serif",
        fontSize: 15,
        fontWeight: 700,
        marginBottom: 6,
        lineHeight: 1.3,
        color: "#e8e8f0",
      }}>
        {data.title?.slice(0, 80)}{data.title?.length > 80 ? "…" : ""}
      </div>
      <div style={{ fontSize: 12, color: "#8888a8", marginBottom: 14 }}>
        by {data.creator}
      </div>
      <div style={{ display: "flex", gap: 6, marginBottom: 8 }}>
        <StatBadge label="Views" value={fmt(data.views)} color={color} />
        <StatBadge label="Likes" value={fmt(data.likes)} color={color} />
        <StatBadge label="Comments" value={fmt(data.comments)} color={color} />
      </div>
      <div style={{ display: "flex", gap: 6 }}>
        <StatBadge label="Engagement" value={data.engagement_rate + "%"} color="#4ade80" />
        <StatBadge label="Duration" value={Math.floor(data.duration_seconds / 60) + "m " + (data.duration_seconds % 60) + "s"} color={color} />
        <StatBadge label="Upload" value={data.upload_date} color={color} />
      </div>
      {data.hashtags?.length > 0 && (
        <div style={{ marginTop: 10, display: "flex", flexWrap: "wrap", gap: 4 }}>
          {data.hashtags.slice(0, 5).map((tag, i) => (
            <span key={i} style={{
              fontSize: 10, padding: "2px 8px",
              background: color + "15",
              border: `1px solid ${color}33`,
              borderRadius: 10,
              color: "#8888a8",
            }}>
              #{typeof tag === "string" ? tag.replace(/^#/, "") : tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function Message({ msg }) {
  const isUser = msg.role === "user";
  return (
    <div style={{
      display: "flex",
      justifyContent: isUser ? "flex-end" : "flex-start",
      marginBottom: 12,
    }}>
      <div style={{
        maxWidth: "80%",
        padding: "10px 14px",
        borderRadius: isUser ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
        background: isUser
          ? "linear-gradient(135deg, #6c63ff, #9b8fff)"
          : "#1a1a24",
        border: isUser ? "none" : "1px solid #2a2a38",
        fontSize: 14,
        lineHeight: 1.6,
        color: "#e8e8f0",
        whiteSpace: "pre-wrap",
      }}>
        {msg.content}
        {msg.sources?.length > 0 && (
          <div style={{ marginTop: 8, borderTop: "1px solid #ffffff15", paddingTop: 8 }}>
            {msg.sources.map((s, i) => (
              <div key={i} style={{ fontSize: 11, color: "#8888a8", marginBottom: 3 }}>
                📎 {s.source}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [urlA, setUrlA] = useState("");
  const [urlB, setUrlB] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState("");
  const [videos, setVideos] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState("");
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleIngest = async () => {
    if (!urlA.trim() || !urlB.trim()) {
      setError("Please enter both URLs.");
      return;
    }
    setError("");
    setLoading(true);
    setLoadingMsg("Fetching transcripts and metadata…");
    try {
      const res = await fetch(`${API}/ingest`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url_a: urlA.trim(), url_b: urlB.trim() }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Ingest failed");
      }
      const data = await res.json();
      setVideos({ A: data.video_a, B: data.video_b });
      setMessages([{
        role: "assistant",
        content: `✅ Both videos ingested! I've analysed:\n\n🎬 **Video A**: ${data.video_a.title}\n🎬 **Video B**: ${data.video_b.title}\n\nAsk me anything about these videos — engagement, hooks, improvements, comparisons!`,
        sources: [],
      }]);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setLoadingMsg("");
    }
  };

  const handleChat = async (msg) => {
    const text = msg || input.trim();
    if (!text || streaming || !videos) return;
    setInput("");

    const userMsg = { role: "user", content: text, sources: [] };
    setMessages((prev) => [...prev, userMsg]);
    setStreaming(true);

    const assistantMsg = { role: "assistant", content: "", sources: [] };
    setMessages((prev) => [...prev, assistantMsg]);

    try {
      const res = await fetch(`${API}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let fullContent = "";
      let sources = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const data = line.slice(6);
          if (data === "[DONE]") continue;

          if (data.includes("__SOURCES__")) {
            const match = data.match(/__SOURCES__(.*?)__END_SOURCES__/s);
            if (match) {
              try { sources = JSON.parse(match[1]); } catch {}
              // Remove sources marker from content
              const cleanData = data.replace(/__SOURCES__.*?__END_SOURCES__/s, "").replace(/\n\n$/, "");
              if (cleanData) fullContent += cleanData;
            }
          } else {
            fullContent += data;
          }

          setMessages((prev) => {
            const updated = [...prev];
            updated[updated.length - 1] = {
              role: "assistant",
              content: fullContent,
              sources,
            };
            return updated;
          });
        }
      }
    } catch (e) {
      setMessages((prev) => {
        const updated = [...prev];
        updated[updated.length - 1] = {
          role: "assistant",
          content: "Sorry, something went wrong. Make sure the backend is running.",
          sources: [],
        };
        return updated;
      });
    } finally {
      setStreaming(false);
    }
  };

  const handleReset = async () => {
    await fetch(`${API}/chat/reset`, { method: "POST" });
    setVideos(null);
    setMessages([]);
    setUrlA("");
    setUrlB("");
    setError("");
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <div style={{
        borderBottom: "1px solid #2a2a38",
        padding: "16px 32px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: "#0a0a0f",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}>
        <div>
          <div style={{ fontFamily: "Syne, sans-serif", fontSize: 22, fontWeight: 800, color: "#e8e8f0" }}>
            <span style={{ color: "#6c63ff" }}>Video</span> RAG Analyser
          </div>
          <div style={{ fontSize: 12, color: "#8888a8", marginTop: 2 }}>
            Compare · Analyse · Improve
          </div>
        </div>
        {videos && (
          <button onClick={handleReset} style={{
            background: "transparent",
            border: "1px solid #2a2a38",
            borderRadius: 8,
            padding: "7px 16px",
            color: "#8888a8",
            cursor: "pointer",
            fontSize: 13,
          }}>
            ↺ New Session
          </button>
        )}
      </div>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", maxWidth: 1200, margin: "0 auto", width: "100%", padding: "24px 24px 0" }}>
        {/* URL Input */}
        {!videos && (
          <div style={{
            background: "#111118",
            border: "1px solid #2a2a38",
            borderRadius: 20,
            padding: 32,
            marginBottom: 24,
          }}>
            <div style={{ fontFamily: "Syne, sans-serif", fontSize: 18, fontWeight: 700, marginBottom: 6 }}>
              Analyse Two Videos
            </div>
            <div style={{ fontSize: 13, color: "#8888a8", marginBottom: 24 }}>
              Paste YouTube or Instagram URLs. The AI will fetch transcripts, metadata, and build a RAG index for comparison.
            </div>
            <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, color: "#6c63ff", fontWeight: 700, marginBottom: 6, textTransform: "uppercase", letterSpacing: 1 }}>Video A</div>
                <input
                  value={urlA}
                  onChange={(e) => setUrlA(e.target.value)}
                  placeholder="https://youtube.com/watch?v=..."
                  style={{
                    width: "100%",
                    background: "#0a0a0f",
                    border: "1px solid #2a2a38",
                    borderRadius: 10,
                    padding: "10px 14px",
                    color: "#e8e8f0",
                    fontSize: 13,
                    outline: "none",
                  }}
                />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, color: "#ff6584", fontWeight: 700, marginBottom: 6, textTransform: "uppercase", letterSpacing: 1 }}>Video B</div>
                <input
                  value={urlB}
                  onChange={(e) => setUrlB(e.target.value)}
                  placeholder="https://youtube.com/watch?v=..."
                  style={{
                    width: "100%",
                    background: "#0a0a0f",
                    border: "1px solid #2a2a38",
                    borderRadius: 10,
                    padding: "10px 14px",
                    color: "#e8e8f0",
                    fontSize: 13,
                    outline: "none",
                  }}
                />
              </div>
            </div>
            {error && <div style={{ color: "#ff6584", fontSize: 13, marginBottom: 12 }}>⚠ {error}</div>}
            <button
              onClick={handleIngest}
              disabled={loading}
              style={{
                background: loading ? "#3a3a50" : "linear-gradient(135deg, #6c63ff, #9b8fff)",
                border: "none",
                borderRadius: 10,
                padding: "11px 28px",
                color: "#fff",
                fontSize: 14,
                fontWeight: 600,
                cursor: loading ? "not-allowed" : "pointer",
                fontFamily: "Syne, sans-serif",
              }}
            >
              {loading ? loadingMsg || "Processing…" : "▶ Analyse Videos"}
            </button>
            <div style={{ marginTop: 16, fontSize: 12, color: "#8888a8" }}>
              💡 Try: <span style={{ color: "#6c63ff", cursor: "pointer" }} onClick={() => { setUrlA("https://www.youtube.com/watch?v=arj7oStGLkU"); setUrlB("https://www.youtube.com/watch?v=mNBmG24djoY"); }}>Load demo TED talks</span>
            </div>
          </div>
        )}

        {/* Video Cards */}
        {videos && (
          <div style={{ display: "flex", gap: 16, marginBottom: 20 }}>
            <VideoCard label="A" data={videos.A} color="#6c63ff" />
            <VideoCard label="B" data={videos.B} color="#ff6584" />
          </div>
        )}

        {/* Chat */}
        {videos && (
          <div style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            background: "#111118",
            border: "1px solid #2a2a38",
            borderRadius: 20,
            overflow: "hidden",
            marginBottom: 24,
            minHeight: 400,
          }}>
            {/* Messages */}
            <div style={{ flex: 1, overflowY: "auto", padding: "20px 20px 0" }}>
              {messages.map((msg, i) => <Message key={i} msg={msg} />)}
              {streaming && messages[messages.length - 1]?.content === "" && (
                <div style={{ display: "flex", gap: 4, padding: "10px 14px" }}>
                  {[0, 1, 2].map((i) => (
                    <div key={i} style={{
                      width: 6, height: 6, borderRadius: "50%",
                      background: "#6c63ff",
                      animation: `bounce 1s ${i * 0.2}s infinite`,
                    }} />
                  ))}
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Suggestions */}
            {messages.length <= 1 && (
              <div style={{ padding: "12px 20px 0", display: "flex", gap: 8, flexWrap: "wrap" }}>
                {SUGGESTIONS.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => handleChat(s)}
                    style={{
                      background: "#0a0a0f",
                      border: "1px solid #2a2a38",
                      borderRadius: 20,
                      padding: "6px 14px",
                      color: "#8888a8",
                      fontSize: 12,
                      cursor: "pointer",
                      transition: "all 0.15s",
                    }}
                    onMouseEnter={(e) => { e.target.style.borderColor = "#6c63ff"; e.target.style.color = "#e8e8f0"; }}
                    onMouseLeave={(e) => { e.target.style.borderColor = "#2a2a38"; e.target.style.color = "#8888a8"; }}
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            {/* Input */}
            <div style={{
              padding: 16,
              borderTop: "1px solid #2a2a38",
              display: "flex",
              gap: 10,
              marginTop: 12,
            }}>
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleChat()}
                placeholder="Ask about engagement, hooks, improvements…"
                disabled={streaming}
                style={{
                  flex: 1,
                  background: "#0a0a0f",
                  border: "1px solid #2a2a38",
                  borderRadius: 10,
                  padding: "10px 14px",
                  color: "#e8e8f0",
                  fontSize: 14,
                  outline: "none",
                }}
              />
              <button
                onClick={() => handleChat()}
                disabled={streaming || !input.trim()}
                style={{
                  background: streaming || !input.trim() ? "#1a1a24" : "linear-gradient(135deg, #6c63ff, #9b8fff)",
                  border: "none",
                  borderRadius: 10,
                  padding: "10px 20px",
                  color: streaming || !input.trim() ? "#8888a8" : "#fff",
                  fontSize: 14,
                  cursor: streaming || !input.trim() ? "not-allowed" : "pointer",
                  fontWeight: 600,
                }}
              >
                Send →
              </button>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); opacity: 0.4; }
          50% { transform: translateY(-6px); opacity: 1; }
        }
        input:focus { border-color: #6c63ff !important; }
      `}</style>
    </div>
  );
}
